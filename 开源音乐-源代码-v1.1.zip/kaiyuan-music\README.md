# 开源音乐 Liquid Music v1.1

液态玻璃风格的音乐播放与识曲应用。Web 版（Node.js 后端）+ Android App（Capacitor）。

## 功能特性

- **多平台音乐搜索**：网易云音乐、酷狗音乐、QQ 音乐，结果交织排序
- **听歌识曲**：麦克风实时录音 / 本地音频上传，基于 ACRCloud 识别引擎
- **液态玻璃 UI**：实时调节模糊度、饱和度、透明度、高光强度、主色调 hue
- **背景主题**：6 套内置渐变主题 + 纯色模式
- **播放器**：歌词同步、进度控制、播放模式、收藏、迷你播放器
- **VIP / 管理员解锁**：2054（VIP金色主题）、admin1（管理后台）、0806（关闭防逆向）
- **防逆向保护**：定时 debugger 检测

## 目录结构

```
├─ public/          前端页面（app.js / index.html / style.css / sw.js）
├─ server.js        后端服务（零依赖，Node.js 内置模块）
├─ capacitor.config.json    Capacitor 配置
├─ package.json     Node 项目描述
├─ .gitignore
└─ android/         Android 原生项目（Capacitor / Gradle 打包）
   ├─ app/
   │  └─ src/main/
   │     ├─ java/com/kaiyuan/music/MainActivity.java
   │     ├─ res/               图标 / 启动图 / 资源
   │     ├─ AndroidManifest.xml
   │     └─ assets/public/     由 public/ 同步生成（构建 APK 时生成）
   ├─ capacitor-cordova-android-plugins/
   ├─ gradle/  gradlew  gradlew.bat
   ├─ build.gradle  settings.gradle  variables.gradle
   └─ local.properties   本机 SDK 路径（.gitignore 已排除，本地自行配置）
```

## 快速开始（Web 版）

```bash
node server.js
# 浏览器打开 http://localhost:3000
```

### 听歌识曲凭证配置

三种方式任选其一（优先级从上到下）：

1. 在 App 管理后台 → 「ACRCloud 凭证」输入框里手动填写
2. 启动时设置环境变量：
   ```
   set ACR_ACCESS_KEY=your_key
   set ACR_ACCESS_SECRET=your_secret
   node server.js
   ```
3. 编辑 `public/app.js` 中的 `ACR_DEFAULT_ACCESS_KEY` 与 `ACR_DEFAULT_ACCESS_SECRET`（公开代码仓库前请清空）

讯飞 API（哼唱识曲）同理可通过 `XF_APP_ID` / `XF_API_KEY` 环境变量或前端设置配置。

## 打包 APK

1. 本机安装 JDK 17、Android SDK（platforms;android-34、build-tools;34.0.0）
2. 在项目根写好 `android/local.properties`，例如：`sdk.dir=C:/Android/Sdk`
3. 同步前端资源：`xcopy /E /Y public\* android\app\src\main\assets\public\`
4. 编译：`cd android && gradlew assembleDebug`
5. APK 输出：`android/app/build/outputs/apk/debug/app-debug.apk`

## 打包 Windows exe （iexpress SFX）

见 `.build-exe/`（本地构建中间目录，已加 .gitignore，不会入库）。

## 敏感信息提醒

`public/app.js` 内 `ACR_DEFAULT_ACCESS_KEY` / `ACR_DEFAULT_ACCESS_SECRET` 默认值仅供本机调试；推送到公共仓库前请务必清空，改为环境变量或管理后台手动输入方式，避免 Key 被爬虫抓取产生费用。
